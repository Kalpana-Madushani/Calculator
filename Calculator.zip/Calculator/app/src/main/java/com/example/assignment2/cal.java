package com.example.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class cal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cal);
    }

    public void add(View v){
        EditText num1 = (EditText)findViewById(R.id.txtfnum);
        EditText num2 = (EditText)findViewById(R.id.txtsnum);
        EditText A = (EditText)findViewById(R.id.txtans);
        Double x = Double.parseDouble(num1.getText().toString());
        Double  y= Double.parseDouble(num2.getText().toString());
        Double result= (x + y);
        A.setText("Answer : " + result);
    }

    public void subs(View v){
        EditText num1 = (EditText)findViewById(R.id.txtfnum);
        EditText num2 = (EditText)findViewById(R.id.txtsnum);
        EditText A = (EditText)findViewById(R.id.txtans);
        Double x = Double.parseDouble(num1.getText().toString());
        Double  y= Double.parseDouble(num2.getText().toString());
        Double result= (x - y);
        A.setText("Answer : " + result);
    }

    public void mul(View v){
        EditText num1 = (EditText)findViewById(R.id.txtfnum);
        EditText num2 = (EditText)findViewById(R.id.txtsnum);
        EditText A = (EditText)findViewById(R.id.txtans);
        Double x = Double.parseDouble(num1.getText().toString());
        Double  y= Double.parseDouble(num2.getText().toString());
        Double result= (x * y);
        A.setText("Answer : " + result);
    }

    public void div(View v){
        EditText num1 = (EditText)findViewById(R.id.txtfnum);
        EditText num2 = (EditText)findViewById(R.id.txtsnum);
        EditText A = (EditText)findViewById(R.id.txtans);
        Double x = Double.parseDouble(num1.getText().toString());
        Double  y= Double.parseDouble(num2.getText().toString());
        Double result= (x / y);
        A.setText("Answer : " + result);
    }

    public void mod(View v){
        EditText num1 = (EditText)findViewById(R.id.txtfnum);
        EditText num2 = (EditText)findViewById(R.id.txtsnum);
        EditText A = (EditText)findViewById(R.id.txtans);
        Double x = Double.parseDouble(num1.getText().toString());
        Double  y= Double.parseDouble(num2.getText().toString());
        Double result= (x % y);
        A.setText("Answer : " + result);
    }
}